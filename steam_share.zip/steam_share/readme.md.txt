Make sure you have VS Code

Open the Steam folder in VS Code

Open the terminal at the top by clicking Terminal - New Terminal 

Copy the contents of install any admin.txt 

2-finger click inside the terminal 

Run the command

When choosing where to install Steam, choose the steam_launcher folder in the steam folder (wherever you unzipped the file)

I think that should be it. 

Let me know if you need help at johart2030@loyolablakefield.org!
